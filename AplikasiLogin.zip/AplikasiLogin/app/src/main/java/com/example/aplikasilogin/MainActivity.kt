package com.example.aplikasilogin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)


        val btnKeluar: Button = findViewById(R.id.btnKeluar)
        val btnReset: Button = findViewById(R.id.btnReset)
        val btnSubmit = findViewById<Button>(R.id.btnSubmit)
        val inputUsername = findViewById<EditText>(R.id.inputUsername)
        val inputPassword: EditText = findViewById(R.id.inputPassword)

        btnSubmit.setOnClickListener {
            val username: String = inputUsername.text.toString()
            val password: String = inputPassword.text.toString()

            val usernameValid = "usm"
            val passwordValid = "jaya"

            if (username.equals(usernameValid) && password.equals(passwordValid)) {
                Toast.makeText(
                    applicationContext, "login berhasil,username  : "
                            + username, Toast.LENGTH_LONG
                ).show()
                val intent: Intent = Intent( this, DaftarActivity::class.java)
                startActivity(intent)
            } else {

                Toast.makeText(applicationContext, "login gagal", Toast.LENGTH_LONG).show()
            }
        }


        btnReset.setOnClickListener {
            inputUsername.setText("")
            inputPassword.setText("")

        }


            btnKeluar.setOnClickListener {
                finish()
            }
            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
                insets
            }
        }
    }


