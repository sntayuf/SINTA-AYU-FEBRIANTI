package com.example.aplikasilogin

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class DaftarActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_daftar)

        var inputDataNIM:EditText = findViewById(R.id.inpNIM)
        var inputDataNama:EditText = findViewById(R.id.inpNama)
        var inputDataEmail:EditText = findViewById(R.id.inpEmail)
        var inputDataPassword: EditText = findViewById(R.id.inpPassword)
        val btnAksiDaftar: Button = findViewById(R.id.buttonDaftar)
        val btnAksiBersih: Button = findViewById(R.id.buttonBersih)
        val btnAksiBatal: Button = findViewById(R.id.buttonBatal)


        btnAksiBersih.setOnClickListener {
            inputDataNIM.setText("")
            inputDataNama.setText("")
            inputDataEmail.setText("")
            inputDataPassword.setText("")
        }

        btnAksiDaftar.setOnClickListener {

            if(inputDataNIM.equals("") || inputDataNama.equals("")
                || inputDataEmail.equals("") || inputDataPassword.equals("")){
                Toast.makeText(applicationContext,"Tidak boleh ada yang kosong", Toast.LENGTH_LONG).show()
            }
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}